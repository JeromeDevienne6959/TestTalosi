public class Main {
    public static void main(String[] args) {
        ThreeStack threeStack = new ThreeStack();

        threeStack.push(1, new Object("object 1"));
        threeStack.push(1, new Object("object 2"));
        threeStack.push(2, new Object("object 3"));
        threeStack.push(2, new Object("object 4"));
        threeStack.push(2, new Object("object 5"));
        threeStack.push(3, new Object("object 6"));
        threeStack.push(3, new Object("object 7"));

        threeStack.pop(2);
        threeStack.pop(2);
        threeStack.pop(1);
        threeStack.pop(1);
        threeStack.pop(3);
        threeStack.pop(1);
        threeStack.pop(4);
    }
}