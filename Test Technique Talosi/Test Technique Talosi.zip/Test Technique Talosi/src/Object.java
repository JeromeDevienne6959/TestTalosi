public class Object {
    //ATTRIBUTS

    private String name;

    //CONSTRUCTEURS

    public Object(String name) {
        this.name = name;
    }

    //GETTERS
    public String getName() {
        return name;
    }

    //SETTERS
    //METHODES


    @Override
    public String toString() {
        return "Object{\n" +
                "\tname='" + name + "\n" +
                '}';
    }
}
