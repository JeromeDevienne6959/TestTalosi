import java.util.ArrayList;

public class Stack {
    //ATTRIBUTS
    private ArrayList<Object> stack;
    private int id;

    //CONSTRUCTEURS

    public Stack(int id) {
        this.stack = new ArrayList<>();
        this.id = id;
    }

    //GETTERS

    public int getId() {
        return id;
    }

    //SETTERS
    //METHODES

    public void add(Object o){
        this.stack.add(0,o);
    }

    public Object pop(){
        if(this.stack.isEmpty()){
            System.out.println("La Stack est vide");
            return null;
        }
        else{
            return this.stack.remove(0);
        }

    }
}
