import java.util.ArrayList;

public class ThreeStack {
    //ATTRIBUTS
    private ArrayList<Stack> threeStacks;

    //CONSTRUCTEURS

    public ThreeStack() {
        Stack s1 = new Stack(1);
        Stack s2 = new Stack(2);
        Stack s3 = new Stack(3);
        this.threeStacks = new ArrayList<>();
        this.threeStacks.add(s1);
        this.threeStacks.add(s2);
        this.threeStacks.add(s3);
    }

    //GETTERS
    //SETTERS
    //METHODES
    public int push(int numero, Object o){
        for(int i=0; i<this.threeStacks.size(); i++){
            if(this.threeStacks.get(i).getId() == numero){
                this.threeStacks.get(i).add(o);
                return 0;
            }
        }
        System.out.println("Pas de Stack numero "+numero);
        return 0;
    }

    public int pop(int numero){
        Object returnO;
        for(int i=0; i<this.threeStacks.size(); i++){
            if(this.threeStacks.get(i).getId() == numero){
                Object retour = this.threeStacks.get(i).pop();
                if(retour != null){
                    System.out.println(retour);
                    return 0;
                }
                else{
                    return 0;
                }
            }
        }
        System.out.println("Pas de Stack numero "+numero);
        return 0;
    }
}
